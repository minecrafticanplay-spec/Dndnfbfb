package com.baha.askai;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class AskActivity extends Activity {
    String selected = "";
    boolean readOnly = true;
    String lastAnswer = "";
    TextView answerView;
    EditText input;
    Button replaceBtn;
    int seq = 0;

    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    TextView tv(String t, int sp, int color) {
        TextView x = new TextView(this);
        x.setText(t);
        x.setTextSize(sp);
        x.setTextColor(color);
        x.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        x.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        return x;
    }

    Button chip(String label, final String instruction) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(v -> send(instruction));
        return b;
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        CharSequence t = getIntent().getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
        selected = t == null ? "" : t.toString().trim();
        readOnly = getIntent().getBooleanExtra(Intent.EXTRA_PROCESS_TEXT_READONLY, false);

        getWindow().setGravity(Gravity.BOTTOM);
        getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(14));
        sv.addView(root);

        TextView sel = tv(selected, 13, Color.parseColor("#9ca3af"));
        sel.setMaxLines(3);
        sel.setEllipsize(TextUtils.TruncateAt.END);
        root.addView(sel);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.addView(chip("اشرح", "اشرح هذا النص بإيجاز ووضوح."));
        chips.addView(chip("ترجم", "ترجم النص إلى العربية إن كان بلغة أخرى، وإلى الإنجليزية إن كان بالعربية. اكتب الترجمة فقط."));
        chips.addView(chip("لخّص", "لخّص هذا النص في نقاط قصيرة."));
        chips.addView(chip("صحّح", "صحّح الأخطاء الإملائية والنحوية في النص، واكتب النص المصحّح فقط."));
        hs.addView(chips);
        root.addView(hs);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        input = new EditText(this);
        input.setHint("اسأل سؤالًا عن النص (اختياري)");
        input.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        row.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button ask = new Button(this);
        ask.setText("اسأل");
        ask.setOnClickListener(v -> {
            String q = input.getText().toString().trim();
            send(q.isEmpty() ? defaultInstruction() : q);
        });
        row.addView(ask);
        root.addView(row);

        answerView = tv("", 16, Color.WHITE);
        answerView.setTextIsSelectable(true);
        answerView.setPadding(0, dp(10), 0, dp(10));
        root.addView(answerView);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button copy = new Button(this);
        copy.setText("نسخ الإجابة");
        copy.setOnClickListener(v -> {
            if (lastAnswer.isEmpty()) return;
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("answer", lastAnswer));
            Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show();
        });
        actions.addView(copy);
        replaceBtn = new Button(this);
        replaceBtn.setText("استبدال النص");
        replaceBtn.setVisibility(readOnly ? View.GONE : View.VISIBLE);
        replaceBtn.setOnClickListener(v -> {
            if (lastAnswer.isEmpty()) return;
            Intent r = new Intent();
            r.putExtra(Intent.EXTRA_PROCESS_TEXT, lastAnswer);
            setResult(RESULT_OK, r);
            finish();
        });
        actions.addView(replaceBtn);
        Button close = new Button(this);
        close.setText("إغلاق");
        close.setOnClickListener(v -> finish());
        actions.addView(close);
        root.addView(actions);

        setContentView(sv);

        if (selected.isEmpty()) {
            answerView.setText("لم يتم تحديد نص.");
        } else {
            send(defaultInstruction());
        }
    }

    String defaultInstruction() {
        return "إن كان النص سؤالًا فأجب عنه، وإلا فاشرحه باختصار.";
    }

    void setAnswer(final int id, final String text, final boolean ok) {
        runOnUiThread(() -> {
            if (id != seq) return;
            answerView.setText(text);
            if (ok) lastAnswer = text;
        });
    }

    void send(final String instruction) {
        if (selected.isEmpty()) return;
        SharedPreferences sp = getSharedPreferences("cfg", 0);
        final String key = sp.getString("key", "");
        final String model = sp.getString("model", "gemini-3.5-flash");
        final int id = ++seq;
        lastAnswer = "";
        if (key.isEmpty()) {
            answerView.setText("لم يتم إدخال مفتاح Gemini. افتح التطبيق من الشاشة الرئيسية وأدخل المفتاح أولًا.");
            return;
        }
        answerView.setText("جارٍ التفكير...");
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject()
                        .put("text", "أنت مساعد مفيد. أجب بإيجاز وبنفس لغة المستخدم."))));
                body.put("contents", new JSONArray().put(new JSONObject().put("role", "user")
                        .put("parts", new JSONArray().put(new JSONObject()
                                .put("text", "النص المحدد:\n" + selected + "\n\nالمطلوب: " + instruction)))));

                HttpURLConnection c = (HttpURLConnection) new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent").openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("x-goog-api-key", key);
                c.setRequestProperty("Content-Type", "application/json");
                c.setConnectTimeout(20000);
                c.setReadTimeout(60000);
                c.setDoOutput(true);
                OutputStream os = c.getOutputStream();
                os.write(body.toString().getBytes("UTF-8"));
                os.close();

                int code = c.getResponseCode();
                InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while (is != null && (n = is.read(buf)) > 0) bo.write(buf, 0, n);
                String resp = bo.toString("UTF-8");
                if (code >= 400) {
                    String m = resp;
                    try { m = new JSONObject(resp).getJSONObject("error").getString("message"); } catch (Exception ignored) { }
                    setAnswer(id, "خطأ (" + code + "): " + m, false);
                    return;
                }
                JSONArray parts = new JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts");
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < parts.length(); i++) sb.append(parts.getJSONObject(i).optString("text", ""));
                String ans = sb.toString().trim();
                if (ans.isEmpty()) ans = "لم يرجع النموذج إجابة.";
                setAnswer(id, ans, true);
            } catch (Exception e) {
                setAnswer(id, "تعذر الاتصال: " + e.getMessage(), false);
            }
        }).start();
    }
}
